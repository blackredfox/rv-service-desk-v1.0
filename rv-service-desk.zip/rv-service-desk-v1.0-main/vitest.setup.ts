/**
 * Legacy / unused Vitest setup file.
 * This project uses ./tests/setup.ts via vitest.config.ts.
 * Keep this file minimal to avoid accidental breakage.
 */

export {};
